import com.lab.calc.EvaluateExpression;

public class TestExpression {

	public static void main(String[] args) {

		EvaluateExpression evaluateExpression = new EvaluateExpression();
		String input = "100 * ( 2 + 12 )";
		System.out.println(evaluateExpression.evaluate(input));
	}

}
