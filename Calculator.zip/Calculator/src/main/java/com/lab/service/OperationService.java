package com.lab.service;

public interface OperationService {
	
	public int performOperation(char c, int a , int b);
	public boolean checkPrecedence(char c1,char c2);
	

}
