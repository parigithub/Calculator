package com.lab.serviceImpl;

import com.lab.service.OperationService;

public class OperationServiceImpl implements OperationService {

	@Override
	public int performOperation(char c, int a,int b) {
		switch (c) 
		{ 
		case '+': 
			return a + b; 
		case '-': 
			return a - b; 
		case '*': 
			return a * b; 
		case '/': 
			if (b == 0) 
				throw new
				UnsupportedOperationException("Cannot divide by zero"); 
			return a / b; 
		} 
		return 0; 
	}

	@Override
	public boolean checkPrecedence(char c1,char c2) {
		if (c1 == '(' || c2 == ')') 
			return false; 
		if ((c1 == '*' || c1 == '/') && (c2 == '+' || c2 == '-')) 
			return false; 
		else
			return true; 
	}

}
